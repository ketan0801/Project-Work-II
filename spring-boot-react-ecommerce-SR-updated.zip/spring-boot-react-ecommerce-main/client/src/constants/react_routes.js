export const HOME_ROUTE = '/'
export const PRODUCTS_ROUTE = '/products'
export const CHECKOUT_ROUTE = '/checkout'
export const DETAILS_ROUTE = '/products/details'